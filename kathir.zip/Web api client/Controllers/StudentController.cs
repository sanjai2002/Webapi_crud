using APICrudClient.Models;
using Microsoft.AspNetCore.Mvc;

namespace APICrudclient.Controllers
{
   public class StudentController : Controller


   {

        private readonly APIGateway _apiGateway;
    public StudentController(APIGateway ApiGateway)
    {
        _apiGateway = ApiGateway;
    }



    public IActionResult Index()
    {
        List<Student> student;

        student = _apiGateway.ListStudents();
        return View(student);
    }


    [HttpGet]
    public IActionResult Create()
    {
        Student student =new  Student();
        return View(student);
    }

    [HttpPost]
    public IActionResult Create(Student student)
    {
    
        _apiGateway.CreateCustomer(student);
        return RedirectToAction("index");
    }


     public IActionResult Details(int id)
    {
       Student student =new  Student();
       student = _apiGateway.GetCustomer(id);
        return View(student);
    }


    [HttpGet]
    public IActionResult Edit(int Id)
    {
         Student student;
         student = _apiGateway.GetCustomer(Id);
        return View(student);
    }   
    
     
    [HttpPost]
    public IActionResult Edit(Student student)
    {
        _apiGateway.UpdateCustomer(student);
          return RedirectToAction("Index");
    }

    [HttpGet]
    public IActionResult Delete(int Id)
    {
         Student student;
          student = _apiGateway.GetCustomer(Id);
        return View(student);
    }

    [HttpPost]
    public IActionResult Delete(Student student)
    {
        _apiGateway.DeleteCustomer(student.Id);
          return RedirectToAction("index");
    }





   }
}